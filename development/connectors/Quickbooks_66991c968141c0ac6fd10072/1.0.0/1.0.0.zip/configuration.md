# How to create a custom Quickbooks app

## Set up your developer account

Go to the [Intuit Developer Portal](https://developer.intuit.com/app/developer/myapps) and create a developer account.
This profile is where you’ll create apps, get app credentials, and set up sandbox companies for testing.

## Create your app on the Intuit Developer Portal

The apps you create on the developer portal generate unique Client ID / Secret credentials you'll need further when creating an integration with the `quickbooks-connector`

- Sign in to your developer account.
- Select the Dashboard tab on the toolbar.
- Go to the Apps tab.
- Select + Create an app.
- Follow the on-screen steps. There are a few things you should pay attention to:
  - **Scopes**: When you create apps, you’ll pick your app’s scopes. Scopes limit the type of data your app can access. If your app only needs access to accounting data, select the accounting scope. If it also needs to access payment data, also select the payments scope.
  - **Redirect URIs**: you may add as many redirect uris as you need, but to be able to create an integration with the `quickbooks-connector` should add `https://api.integration.app/oauth-callback`

## Get the Client ID and Client Secret for your app

Each app has two sets of credentials: one for live production code and another for sandbox and testing environments.

- Sign in to your developer account.
- Select the Dashboard link on the toolbar.
- Select and open an app.
- If you’re connecting a sandbox company, go to the Development section. Then select Keys & OAuth.
- If you’re setting up a production app, go to the Production section. Then select Keys & OAuth.
- Copy and save somewhere safe the Client ID and Client Secret.

## Create an integration with your custom app credentials

Once you've added the Quickbooks connector from store in the integration.app [console](https://console.integration.app/) click Configure & Test -> Edit Parameters and provide the **Client Id** and **Client secret** you saved earlier. Now, you're ready to create a test connection with Quickbooks!
Note that if you're creating connection with your sandbox account, you should switch the "Connect to sandbox instance" toggle on when you see a connection pop-up
