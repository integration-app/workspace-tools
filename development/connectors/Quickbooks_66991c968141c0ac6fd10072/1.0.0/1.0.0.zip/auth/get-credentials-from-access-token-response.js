export default async function getCredentialsFromTokenResponse({
  tokenResponse,
  request,
  connectionParameters,
}) {
  return {
    ...tokenResponse,
    realmId: request.query.realmId,
    isSandbox: connectionParameters?.isSandbox ?? false,
  }
}
