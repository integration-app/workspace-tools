export default async function update({
  apiClient,
  id,
  fields,
  parameters: { objectName },
}) {
  // we need to use the latest SyncToken (recorded on an object) to update it. Otherwise, we get a 5010 error -> https://intuit.me/483j0UI
  const recordRes = await apiClient.get(`${objectName.toLowerCase()}/${id}`)
  const syncToken = recordRes[objectName].SyncToken
  const response = await apiClient.post(`${objectName.toLowerCase()}`, {
    Id: id,
    SyncToken: syncToken,
    ...fields,
    sparse: true, // In contrast to the full update, where the fields not specified in the request are set to NULL
  })

  return {
    id: response[objectName].Id,
  }
}
