To test the integration with Quickbooks, you will need a sandbox account.
Sandbox companies are regionally-specific QuickBooks Online companies with sample data. They look and act just like a normal QuickBooks Online experience.
On the [Intuit developer page](https://developer.intuit.com/app/developer/qbo/docs/develop/sandboxes/manage-your-sandboxes) you can find more information on how to create such an account, set it up and test.

Once you've done with the testing, you may want to make your [app available to external users](https://developer.intuit.com/app/developer/qbo/docs/go-live/publish-app) by following the steps described [here](https://developer.intuit.com/app/developer/qbo/docs/go-live/publish-app).
