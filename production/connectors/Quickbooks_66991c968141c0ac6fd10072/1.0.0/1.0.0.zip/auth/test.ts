import { BadRequestError } from '@integration-app/sdk'

export default async function test({ apiClient, credentials }) {
  const response = await apiClient.get(`/companyinfo/${credentials.realmId}`)
  if (!response.CompanyInfo) {
    throw new BadRequestError('Connection test failed')
  }
  return true
}
