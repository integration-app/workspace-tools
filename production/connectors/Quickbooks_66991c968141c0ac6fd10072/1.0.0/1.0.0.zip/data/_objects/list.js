const MAX_RESULTS = 100

export default async function list({ apiClient, cursor, parameters, filter }) {
  const queryStr = makeQuery(parameters, filter, cursor)
  const response = await apiClient.get('query', { query: queryStr })

  return {
    records: response.QueryResponse[parameters.objectName],
    cursor:
      response.QueryResponse.maxResults < MAX_RESULTS
        ? null
        : (response.QueryResponse.startPosition + MAX_RESULTS).toString(),
  }
}

function makeQuery(parameters, filter, cursor) {
  if (filter) {
    const conditions = Object.entries(filter)
      .map(([key, value]) => `${key} = '${value}'`)
      .join(' and ')
    return `select * from ${
      parameters.objectName
    } where ${conditions} startposition ${
      cursor ?? 1
    } maxresults ${MAX_RESULTS}`
  }
  return `select * from ${parameters.objectName} startposition ${
    cursor ?? 1
  } maxresults ${MAX_RESULTS}`
}
