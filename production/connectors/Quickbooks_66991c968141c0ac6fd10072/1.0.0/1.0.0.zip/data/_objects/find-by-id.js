export default async function findById({ apiClient, id, parameters }) {
  const nameLower = parameters.objectName.toLowerCase()
  const response = await apiClient.get(`${nameLower}/${id}`)

  return {
    record: response[parameters.objectName],
  }
}
