export default async function create({
  apiClient,
  fields,
  parameters: { objectName },
}) {
  const response = await apiClient.post(`${objectName.toLowerCase()}`, fields)

  return {
    id: response[objectName].Id,
  }
}
