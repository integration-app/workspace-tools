export default function getConnectionInfo({credentials}) {
  return {
    realmId: credentials.realmId
  }
}